# Getting Started with Create React App

This project was bootstrapped with [Create React App](https://github.com/facebook/create-react-app).

## About It!
Jacqueline Sandor created this simple website to explore more about javascript react and get into front-end design!
